"""Hermes Decision Inbox plugin package."""

__version__ = "0.3.4"

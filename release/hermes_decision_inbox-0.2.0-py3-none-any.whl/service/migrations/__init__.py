"""Bundled SQLite migrations."""

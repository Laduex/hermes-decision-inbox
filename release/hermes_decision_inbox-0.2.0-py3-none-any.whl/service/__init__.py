"""Decision Inbox companion service."""

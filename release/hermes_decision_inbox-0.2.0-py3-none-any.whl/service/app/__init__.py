"""FastAPI service package."""
